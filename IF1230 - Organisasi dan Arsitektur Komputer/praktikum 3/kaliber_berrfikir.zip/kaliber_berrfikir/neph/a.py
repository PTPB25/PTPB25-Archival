from pwn import *
import string

a = b"`QUUUU"
a = a.ljust(8,b'\x00')
a = u64(a)
print(hex(a))




